hyper = {"cmd", "ctrl", "alt"}
hyperShift = {"alt", "shift"}
hyperCtrl = {"alt", "ctrl"}
hyperAlt = {"ctrl", "alt", "shift"}
hyperCmd = {"alt", "cmd"}